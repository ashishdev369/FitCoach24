import React from 'react'
import { Router } from 'react-router'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import style from './Login.css'

//const config = require('../../../../../server_config.json')

class Login extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      appMode: [],
      errorMessage: ''
    };

    this.handleSubmit = this.handleSubmit.bind(this);

  }

  componentDidMount() {

  }


  componentWillMount() {
    // document.addEventListener("keydown", this.handleDocumentKeyDown.bind(this));
  }
  componentWillUnmount() {
    // document.removeEventListener("keydown", this.handleDocumentKeyDown.bind(this));
  }
  handleDocumentKeyDown = (event) => {
    // if (event.keyCode == 13) {
    //   $("#btnSubmit").focus();
    //   this.handleSubmit.bind(this);
    // }
  }

  handleSubmit(event) {

    event.preventDefault();
    var loginParams = {
      username: this.refs.txtUserName.value,
      password: this.refs.txtPassword.value
    }
  }

  render() {
    return (
      <div id="extr-page">
        <div id="main" role="main" className="animated fadeInDown">
          <div className="row fitWidth">
            <div className="col-md-6">
              <img className='imgFitCoach' src={require('../../../assets/images/fitCoachLogin.png')} />
            </div>
            <div className="col-md-6 top-margin">
              <div className="container">
                <div className="col-md-8 offset-md-2">
                  <div className="forms-container">
                    <h3 align="center"><strong>Welcome</strong> to FitCoach24</h3>
                    <hr style={{ width: '30px', 'backgroundColor': 'red' }} />
                    <p style={{ fontSize: '14px' }}> To stay connected with us please login with your email and password.</p>
                    <form className="form-horizontal">
                      <div className="form-group">
                        <input type="text" className="form-control text" placeholder="Username" onFocus autoComplete="off" />
                      </div>
                      <div className="form-group">
                        <input type="password" className="form-control" placeholder="Password" />
                      </div>
                      <center><button type="button" className="btn btn-info">Sign in</button></center>
                    </form>
                    <center><span>or you can join with</span></center>
                    <div className="socio-icons">
                      <i className="fa fa-facebook"></i>
                      <i className="fa fa-google"></i>
                    </div>
                    <div className="terms-condition">
                      <span style={{ display: 'block', textAlign: 'center' }}>By proceeding further, you are agreeing to</span>
                      <center><a href="">Terms & Conditions</a></center>
                    </div>
                    <div className="sign-up">
                      <center><span> New User? <a href="#">Sign Up</a></span></center>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default (Login)