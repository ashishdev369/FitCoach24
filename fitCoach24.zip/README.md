##Steps of running this project

from the command prompt clone the project

download the zip and extract the zip file.
run command npm module
run command npm start
running url: http://localhost:3000/
