## Get Started
1. download zip file
2. Run npm install inside its root folder.
3. run npm start
4. Go to http://localhost:3000 in your browser to see it in action.


